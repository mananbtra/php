<?php
	$bool = true;
	var_dump($bool);
	echo "<br> This code is executed by Deepanshu Sharma!";
?>