<?php
	$num = 10;
	$fnum = 1.1;
	$name = "Deepanshu";
	echo "<br>The String: $name";
	echo "<br>The Integer: $num";
	echo "<br>The Float: $fnum";
	echo "<br>This program is executed by Deepanshu Sharma!";
?>