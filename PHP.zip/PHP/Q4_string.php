<?php
	$name = "Deepanshu Sharma!";
	echo "This program is executed by $name";
?>