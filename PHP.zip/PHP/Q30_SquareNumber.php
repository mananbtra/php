<?php
	$num = 20;
	$square = $num * $num;
	echo "The square of $num is: ".$square;
	echo "<br> This code is executed by Deepanshu Sharma!"
?>