<?php

    $a = 30;
    $b = 30;

    echo "Use of If-Else-If statement!<br>";

    echo "A --> ". $a. "<br>";
    echo "B --> ". $b. "<br>";

    if($a < $b)
    {
    	echo "B is Bigger.." ;
    }
    elseif ($a == $b)
    {
	echo "A & B are equal..";
    }
    else
    {
	echo "A is Bigger..";
    }
    echo "<br> This program is executed by Deepanshu Sharma!";
?>