<?php
	echo "<h1>While Loop</h1>";
	$i = 1;
	while($i <= 10)
	{
		echo $i. "<br>";
		$i++;
	}
	echo "<br> This program is executed by Deepanshu Sharma!";
?>