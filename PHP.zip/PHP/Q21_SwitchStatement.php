<?php
	$favcolor = "Red";
	switch ($favcolor)
	{
		case "Yellow":
			echo "Yellow colour is here!";
			break;

		case "Red":
			echo "Red colour is here!";
			break;
	
		case "blue":
			echo "Blue colour is here!";
			break;
		
		case "green":
			echo "Green colour is here!";
			break;

		default:
			echo "No colour found!";
		
	}
	echo "<br> This program is executed by Deepanshu Sharma!";
?>