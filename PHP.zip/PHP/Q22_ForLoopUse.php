<?php
	echo "<H1>For Loop </H1>";
	for ($i = 1; $i <= 10; $i++)
	{
		echo $i. "<br>";
	}
	echo "<br> This program is executed by Deepanshu Sharma!";
?>