<?php
	$num = 5;
	$result = 1;
	for($i=$num; $i>=1; $i--){
		$result *= $i;
	}
	echo "Factorial of $num is: $result";
	echo "<br> This code is executed by Deepanshu Sharma!";
?>	