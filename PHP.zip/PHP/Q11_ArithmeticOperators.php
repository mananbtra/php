<?php
	$x = 10;
	$z = 4;
	echo "<h1>Arithmetic Operators in php</h1>";
	echo "$x	+	$z	= ". ($x + $z). "<br>";
	echo "$x	-	$z	= ". ($x - $z). "<br>";
	echo "$x	*	$z	= ". ($x * $z). "<br>";
	echo "$x	/	$z	= ". ($x / $z). "<br>";
	echo "$x	%	$z	= ". ($x % $z). "<br>";
	echo "<br> This code is executed by Deepanshu Sharma!";
?>
	