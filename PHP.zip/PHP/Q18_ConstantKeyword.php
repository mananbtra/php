<?php
	define ("GREETING", "Hello World!");
	echo GREETING;
	//echo greeting; // GREETING and greeting both are diferent
	define ("GREETING", "Hello PHP!");
	echo GREETING;
	echo "This code is executed by Deepanshu Sharma!";
?>