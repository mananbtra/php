<?php
	echo "<h1>Do While Loop</h1>";
	$num = 1;
	do {
		echo "Execution number: ". $num. " ". "<br>";
		$num++;
	} while($num<10);
	echo "<br> This program is executed by Deepanshu Sharma!";
?>