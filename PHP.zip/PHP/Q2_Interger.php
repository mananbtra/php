<?php
	$num = 10;
	echo var_dump($num);
	echo "This program is Executed by Deepanshu Sharma!";
?>