<?php
	$array = array("Red", "Blue", "Green");
	var_dump($array);
	$color_codes = array(
        	"Red" => "#ff0000",
        	"Green" => "#00ff00",
        	"Blue" => "#0000ff");
	echo "<br>Color code type ";
	var_dump($color_codes);
	echo "<br>This code is executed by Deepanshu Sharma!";
?>