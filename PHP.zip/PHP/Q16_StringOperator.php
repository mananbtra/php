<?php

    $x = "Hello";
    $y = " World!";
    echo $x . $y; // Outputs: Hello World!
    echo "<br>";
    $x .= $y;
    echo $x. "<br>"; // Outputs: Hello World!
    echo "This code is executed by Deepanshu Sharma!";

?>