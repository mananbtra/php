<?php
	$a = null;
	echo "A -> ";
	var_dump($a);
	
	$b = "Deepanshu";
	echo "<br>B -> ";
	var_dump($b);
	$b = NULL;
	echo "<br>B value after updating: ";
	var_dump($b);
	echo "<br>This code is executed by Deepanshu Sharma!";
?>
	