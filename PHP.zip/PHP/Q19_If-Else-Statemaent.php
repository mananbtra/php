<?php

    $a = 50;
    $b = 30;
    

    echo "<h1>Use of 'If-else' statement!<br></h1>";

    echo "A --> ". $a. "<br>";
    echo "B --> ". $b. "<br>";

    if($a < $b )
    {
    	echo "B is Bigger.." ;
    }
    else
    {
	echo "A is Bigger..";
    }
    echo "<br> This program is executed by Deepanshu Sharma!";

?>