<?php
	function greet($name){
		return "Hello $name!";
	}
	$r = greet("Deepanshu!");
	echo "$r <br>";
	echo "This program is executed by Deepanshu Sharma!";
?>