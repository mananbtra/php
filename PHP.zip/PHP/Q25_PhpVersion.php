<?php
	echo "<h1>PHP Version Info</h1>";
	echo "Current version of php: ". phpversion();
	echo "<br><br> This program is executed by Deepanshu Sharma!";
?>