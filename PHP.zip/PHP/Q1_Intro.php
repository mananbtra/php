<?php
	echo "<br> This code is executed by Deepanshu Sharma!";
?>