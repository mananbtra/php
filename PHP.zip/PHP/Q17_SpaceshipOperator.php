
<?php

    // Comparing Integers 
    echo (1 <=> 1); // Outputs: 0
    echo "<br>";
    echo 1 <=> 2; // Outputs: -1
    echo "<br>";
    echo 2 <=> 1; // Outputs: 1
    echo "<br>";
     
    // Comparing Strings
    echo "x" <=> "y"; // Outputs: -1
    echo "<br>";
    echo "y" <=> "x"; // Outputs: 1
    echo "<br>";

    echo "This program is executed by Deepanshu Sharma!";

?>