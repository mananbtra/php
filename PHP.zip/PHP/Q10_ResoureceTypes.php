<?php
	$handle = fopen("note.txt", "r");
	var_dump($handle);
	echo "<br> This code is executed by Deepanshu Sharma!";
?>