<?php
	$number = array(1, 2, 3, 4, 5);

	foreach($number as $e){
		echo $e. "<br>";
	}
	echo "This program is executed by Deepanshu Sharma!";	
?>